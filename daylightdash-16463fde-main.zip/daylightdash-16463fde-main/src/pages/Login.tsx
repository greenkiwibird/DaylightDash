import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { LogIn } from "lucide-react";

export default function Login() {
  return (
    <div className="flex items-center justify-center min-h-[70vh]">
      <Card className="w-full max-w-sm animate-fade-in">
        <CardHeader className="text-center">
          <LogIn className="h-8 w-8 text-primary mx-auto mb-2" />
          <CardTitle className="text-xl">Sign In</CardTitle>
          <p className="text-sm text-muted-foreground mt-1">Welcome back to Daylight</p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" placeholder="you@example.com" />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" placeholder="••••••••" />
          </div>
          <Button className="w-full">Sign In</Button>
          <p className="text-xs text-center text-muted-foreground">
            Don't have an account? <span className="text-primary cursor-pointer">Sign up</span>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

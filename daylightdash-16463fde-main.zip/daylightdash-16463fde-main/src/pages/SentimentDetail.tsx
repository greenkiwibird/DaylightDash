import { Link } from "react-router-dom";
import { tickets, sentimentTrend } from "@/data/mockData";
import { SentimentChart } from "@/components/SentimentChart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, SmilePlus, Meh, Frown } from "lucide-react";

const sentimentIcon = { positive: SmilePlus, neutral: Meh, negative: Frown };
const sentimentStyle: Record<string, string> = {
  positive: "text-success",
  neutral: "text-warning",
  negative: "text-urgent",
};

export default function SentimentDetail() {
  const total = tickets.length;
  const byGroup = {
    positive: tickets.filter((t) => t.sentiment === "positive"),
    neutral: tickets.filter((t) => t.sentiment === "neutral"),
    negative: tickets.filter((t) => t.sentiment === "negative"),
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-3">
          <ArrowLeft className="h-4 w-4" />
          Back to Overview
        </Link>
        <h2 className="text-2xl text-foreground">Sentiment Breakdown</h2>
        <p className="text-sm text-muted-foreground mt-1">Detailed view of customer sentiment across {total} tickets</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {(["positive", "neutral", "negative"] as const).map((s) => {
          const Icon = sentimentIcon[s];
          const pct = Math.round((byGroup[s].length / total) * 100);
          return (
            <Card key={s} className="animate-fade-in">
              <CardContent className="p-5 flex items-center gap-4">
                <Icon className={`h-8 w-8 ${sentimentStyle[s]}`} />
                <div>
                  <p className="text-2xl font-semibold text-foreground">{pct}%</p>
                  <p className="text-sm text-muted-foreground capitalize">{s} ({byGroup[s].length})</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <SentimentChart />

      <Card className="animate-fade-in">
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Recent Tickets by Sentiment</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-border">
            {tickets.map((ticket) => {
              const Icon = sentimentIcon[ticket.sentiment];
              return (
                <div key={ticket.id} className="flex items-center gap-3 px-5 py-3.5">
                  <Icon className={`h-4 w-4 shrink-0 ${sentimentStyle[ticket.sentiment]}`} />
                  <div className="flex-1 min-w-0">
                    <span className="text-sm font-medium text-foreground truncate block">{ticket.subject}</span>
                    <span className="text-xs text-muted-foreground">{ticket.customer} · {ticket.id}</span>
                  </div>
                  <Badge variant="outline" className="text-xs capitalize">{ticket.sentiment}</Badge>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

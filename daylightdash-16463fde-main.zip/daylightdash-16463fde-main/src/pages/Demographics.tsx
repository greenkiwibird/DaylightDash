import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { demographicBreakdown } from "@/data/mockData";
import { Briefcase, Heart, Users } from "lucide-react";

function DemoChart({ title, data, icon: Icon }: { title: string; data: { name: string; count: number }[]; icon: React.ElementType }) {
  return (
    <Card className="animate-fade-in">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center gap-2">
          <Icon className="h-5 w-5 text-primary" />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data} layout="vertical" margin={{ left: 80, right: 20 }}>
              <XAxis type="number" tick={{ fontSize: 12 }} className="[&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground" />
              <YAxis dataKey="name" type="category" tick={{ fontSize: 12 }} width={80} className="[&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.75rem",
                  fontSize: 13,
                  color: "hsl(var(--card-foreground))",
                }}
              />
              <Bar dataKey="count" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} name="Customers" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Demographics() {
  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h2 className="text-2xl text-foreground">Demographic Intelligence</h2>
        <p className="text-sm text-muted-foreground mt-1">
          Extracted from customer conversations · Privacy-first approach
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <DemoChart title="By Occupation" data={demographicBreakdown.occupations} icon={Briefcase} />
        <DemoChart title="Health Conditions" data={demographicBreakdown.healthConditions} icon={Heart} />
      </div>

      <DemoChart title="Family Status" data={demographicBreakdown.familyStatus} icon={Users} />

      <Card className="bg-info/5 border-info/15 animate-fade-in">
        <CardContent className="p-5">
          <p className="text-sm text-foreground">
            <strong className="font-medium">Privacy note:</strong> All demographic data is extracted only from information customers voluntarily shared in support conversations. No external data augmentation is used.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

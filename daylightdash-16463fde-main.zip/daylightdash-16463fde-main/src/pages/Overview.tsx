import { Ticket, MessageSquare, AlertTriangle, TrendingUp } from "lucide-react";
import { KpiCard } from "@/components/KpiCard";
import { SentimentChart } from "@/components/SentimentChart";
import { TicketList } from "@/components/TicketList";
import { SunshineCharacter } from "@/components/SunshineCharacter";
import { tickets } from "@/data/mockData";

export default function Overview() {
  const openTickets = tickets.filter((t) => t.status === "open");
  const urgentTickets = tickets.filter((t) => t.urgency === "urgent");
  const positiveRate = Math.round(
    (tickets.filter((t) => t.sentiment === "positive").length / tickets.length) * 100
  );

  return (
    <div className="space-y-6 max-w-6xl">
      <SunshineCharacter
        satisfactionPercent={positiveRate}
        heading="Good morning ☀️"
        subheading="Here's what's happening with your customers today."
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard title="Total Tickets" value={tickets.length} subtitle="Last 7 days" icon={Ticket} to="/tickets?filter=all" />
        <KpiCard title="Open" value={openTickets.length} subtitle="Awaiting response" icon={MessageSquare} variant="warning" to="/tickets?filter=open" />
        <KpiCard title="Urgent" value={urgentTickets.length} subtitle="Needs immediate attention" icon={AlertTriangle} variant="urgent" to="/tickets?filter=urgent" />
        <KpiCard title="Positive Sentiment" value={`${positiveRate}%`} subtitle="Trending up +3%" icon={TrendingUp} variant="success" to="/sentiment" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <TicketList tickets={urgentTickets.length > 0 ? tickets.filter(t => t.urgency === "urgent" || t.urgency === "high") : tickets.slice(0, 5)} title="Priority Tickets" />
        </div>
        <div>
          <SentimentChart />
        </div>
      </div>
    </div>
  );
}

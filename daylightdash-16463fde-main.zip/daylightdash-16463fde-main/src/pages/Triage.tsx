import { tickets, type Ticket } from "@/data/mockData";
import { TicketList } from "@/components/TicketList";

function groupBy<T>(arr: T[], fn: (item: T) => string) {
  return arr.reduce<Record<string, T[]>>((acc, item) => {
    const key = fn(item);
    (acc[key] ||= []).push(item);
    return acc;
  }, {});
}

const categoryLabels: Record<string, string> = {
  shipping: "📦 Shipping Status",
  hardware: "🖥️ Hardware Support",
  software: "💻 Software Questions",
  accessories: "🎧 Accessories",
  general: "💬 General Inquiries",
};

const urgencyOrder = ["urgent", "high", "medium", "low"];

export default function Triage() {
  const openTickets = tickets
    .filter((t) => t.status !== "resolved")
    .sort((a, b) => urgencyOrder.indexOf(a.urgency) - urgencyOrder.indexOf(b.urgency));

  const urgentTickets = openTickets.filter((t) => t.urgency === "urgent" || t.urgency === "high");
  const grouped = groupBy(
    openTickets.filter((t) => t.urgency !== "urgent" && t.urgency !== "high"),
    (t) => t.category
  );

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h2 className="text-2xl text-foreground">Today's Triage</h2>
        <p className="text-sm text-muted-foreground mt-1">
          {openTickets.length} open tickets · {urgentTickets.length} need immediate attention
        </p>
      </div>

      {urgentTickets.length > 0 && (
        <TicketList tickets={urgentTickets} title="⚠️ Urgent & High Priority" />
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {Object.entries(grouped).map(([category, items]) => (
          <TicketList
            key={category}
            tickets={items}
            title={categoryLabels[category] || category}
          />
        ))}
      </div>
    </div>
  );
}

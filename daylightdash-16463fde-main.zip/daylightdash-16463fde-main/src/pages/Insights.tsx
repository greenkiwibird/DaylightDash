import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { topLoves, topPainPoints } from "@/data/mockData";
import { SentimentChart } from "@/components/SentimentChart";
import { TrendingUp, TrendingDown, Minus, Heart, AlertCircle } from "lucide-react";

const trendIcon = {
  up: TrendingUp,
  down: TrendingDown,
  stable: Minus,
};

function InsightList({
  title,
  items,
  variant,
  icon: Icon,
}: {
  title: string;
  items: { theme: string; mentions: number; trend: "up" | "down" | "stable" }[];
  variant: "positive" | "negative";
  icon: React.ElementType;
}) {
  const barColor = variant === "positive" ? "bg-success" : "bg-urgent";
  const max = Math.max(...items.map((i) => i.mentions));

  return (
    <Card className="animate-fade-in">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          <Icon className={`h-5 w-5 ${variant === "positive" ? "text-success" : "text-urgent"}`} />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {items.map((item, i) => {
          const TrendComp = trendIcon[item.trend];
          return (
            <div key={i}>
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-sm font-medium text-foreground">{item.theme}</span>
                <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <span>{item.mentions} mentions</span>
                  <TrendComp className="h-3.5 w-3.5" aria-label={`Trend ${item.trend}`} />
                </div>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden" role="progressbar" aria-valuenow={item.mentions} aria-valuemax={max}>
                <div
                  className={`h-full rounded-full ${barColor} transition-all duration-500`}
                  style={{ width: `${(item.mentions / max) * 100}%` }}
                />
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}

export default function Insights() {
  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h2 className="text-2xl text-foreground">Strategic Insights</h2>
        <p className="text-sm text-muted-foreground mt-1">6-month analysis of 5,000+ customer tickets</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <InsightList title="What Customers Love" items={topLoves} variant="positive" icon={Heart} />
        <InsightList title="What Needs Fixing" items={topPainPoints} variant="negative" icon={AlertCircle} />
      </div>

      <SentimentChart />
    </div>
  );
}

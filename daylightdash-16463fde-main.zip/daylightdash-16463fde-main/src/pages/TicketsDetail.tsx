import { useSearchParams, Link } from "react-router-dom";
import { tickets } from "@/data/mockData";
import { TicketList } from "@/components/TicketList";
import { ArrowLeft } from "lucide-react";

const filterFns: Record<string, (t: typeof tickets[0]) => boolean> = {
  all: () => true,
  open: (t) => t.status === "open",
  urgent: (t) => t.urgency === "urgent" || t.urgency === "high",
};

const titles: Record<string, string> = {
  all: "All Tickets",
  open: "Open Tickets",
  urgent: "Urgent & High Priority Tickets",
};

export default function TicketsDetail() {
  const [params] = useSearchParams();
  const filter = params.get("filter") || "all";
  const fn = filterFns[filter] || filterFns.all;
  const filtered = tickets.filter(fn);

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors mb-3">
          <ArrowLeft className="h-4 w-4" />
          Back to Overview
        </Link>
        <h2 className="text-2xl text-foreground">{titles[filter] || "Tickets"}</h2>
        <p className="text-sm text-muted-foreground mt-1">{filtered.length} tickets found</p>
      </div>
      <TicketList tickets={filtered} title={titles[filter] || "Tickets"} />
    </div>
  );
}

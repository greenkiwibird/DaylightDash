import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { sentimentTrend } from "@/data/mockData";

export function SentimentChart() {
  return (
    <Card className="animate-fade-in">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Sentiment Trend</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={sentimentTrend} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" className="[&>line]:stroke-border" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} className="[&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground" />
              <YAxis tick={{ fontSize: 12 }} className="[&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.75rem",
                  fontSize: 13,
                  color: "hsl(var(--card-foreground))",
                }}
              />
              <Legend />
              <Area type="monotone" dataKey="positive" stackId="1" stroke="hsl(var(--sentiment-positive))" fill="hsl(var(--sentiment-positive) / 0.3)" name="Positive" />
              <Area type="monotone" dataKey="neutral" stackId="1" stroke="hsl(var(--sentiment-neutral))" fill="hsl(var(--sentiment-neutral) / 0.3)" name="Neutral" />
              <Area type="monotone" dataKey="negative" stackId="1" stroke="hsl(var(--sentiment-negative))" fill="hsl(var(--sentiment-negative) / 0.3)" name="Negative" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}

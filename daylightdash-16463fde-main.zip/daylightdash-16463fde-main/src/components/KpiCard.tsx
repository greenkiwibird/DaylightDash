import { Card, CardContent } from "@/components/ui/card";
import { type LucideIcon } from "lucide-react";
import { Link } from "react-router-dom";

interface KpiCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  variant?: "default" | "success" | "warning" | "urgent";
  to?: string;
}

const variantStyles = {
  default: "bg-background/80 border-border",
  success: "bg-success/20 border-success/30",
  warning: "bg-warning/20 border-warning/30",
  urgent: "bg-urgent/20 border-urgent/30",
};

const iconStyles = {
  default: "text-muted-foreground",
  success: "text-success",
  warning: "text-warning",
  urgent: "text-urgent",
};

export function KpiCard({ title, value, subtitle, icon: Icon, variant = "default", to }: KpiCardProps) {
  const content = (
    <Card className={`${variantStyles[variant]} animate-fade-in ${to ? "cursor-pointer hover:ring-2 hover:ring-primary/30 hover:shadow-lg transition-all duration-200" : ""}`}>
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <p className="mt-1 text-3xl font-semibold text-foreground">{value}</p>
            {subtitle && <p className="mt-1 text-xs text-muted-foreground">{subtitle}</p>}
          </div>
          <Icon className={`h-5 w-5 ${iconStyles[variant]}`} aria-hidden="true" />
        </div>
      </CardContent>
    </Card>
  );

  if (to) {
    return <Link to={to} className="block no-underline">{content}</Link>;
  }

  return content;
}

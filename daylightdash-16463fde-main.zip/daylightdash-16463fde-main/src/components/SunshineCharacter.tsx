import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";

type Mood = "happy" | "neutral" | "sad";

interface SunshineCardProps {
  satisfactionPercent: number;
  heading: string;
  subheading: string;
}

function getMood(pct: number): Mood {
  if (pct >= 60) return "happy";
  if (pct >= 40) return "neutral";
  return "sad";
}

function getMoodLabel(mood: Mood) {
  return { happy: "Customers are loving it!", neutral: "Room for improvement", sad: "Needs attention" }[mood];
}

function getMoodSublabel(mood: Mood, pct: number) {
  return {
    happy: `${pct}% positive — keep up the great work`,
    neutral: `${pct}% positive — trending toward better days`,
    sad: `${pct}% positive — let's turn this around`,
  }[mood];
}

export function SunshineCharacter({ satisfactionPercent, heading, subheading }: SunshineCardProps) {
  const mood = getMood(satisfactionPercent);
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setAnimate(true), 100);
    return () => clearTimeout(t);
  }, []);

  const moodColor =
    mood === "happy" ? "--success" : mood === "neutral" ? "--warning" : "--urgent";
  const moodBg = "bg-white/40 border-border";
  const moodBarClass =
    mood === "happy" ? "bg-success" : mood === "neutral" ? "bg-warning" : "bg-urgent";

  return (
    <Card className={`animate-fade-in overflow-hidden relative ${moodBg}`}>
      <CardContent className="p-6 flex items-center justify-between gap-6 flex-wrap">
        {/* Left: heading */}
        <div className="min-w-0">
          <h2 className="text-2xl font-semibold text-foreground">{heading}</h2>
          <p className="text-sm text-muted-foreground mt-1">{subheading}</p>
        </div>

        {/* Right: sunshine + satisfaction */}
        <div className="flex items-center gap-5">
          {/* Sunshine SVG */}
          <div
            className={`relative shrink-0 transition-all duration-700 ${animate ? "scale-100 opacity-100" : "scale-50 opacity-0"}`}
          >
            <div
              className="absolute inset-[-18px] rounded-full animate-pulse"
              style={{
                background: `radial-gradient(circle, hsl(var(${moodColor}) / 0.25) 0%, transparent 70%)`,
              }}
            />
            <svg
              width="72"
              height="72"
              viewBox="0 0 100 100"
              fill="none"
              className="relative z-10"
              aria-hidden="true"
            >
              {Array.from({ length: 10 }).map((_, i) => {
                const angle = (i * 36 - 90) * (Math.PI / 180);
                const x1 = 50 + Math.cos(angle) * 36;
                const y1 = 50 + Math.sin(angle) * 36;
                const x2 = 50 + Math.cos(angle) * 48;
                const y2 = 50 + Math.sin(angle) * 48;
                return (
                  <line
                    key={i}
                    x1={x1} y1={y1} x2={x2} y2={y2}
                    stroke={`hsl(var(${moodColor}))`}
                    strokeWidth="3"
                    strokeLinecap="round"
                    opacity={0.6}
                    style={{ animation: `sunshine-ray-pulse 2.5s ease-in-out ${i * 0.15}s infinite` }}
                  />
                );
              })}
              <circle cx="50" cy="50" r="30" fill={`hsl(var(${moodColor}) / 0.15)`} stroke={`hsl(var(${moodColor}))`} strokeWidth="2.5" />
              {mood === "happy" ? (
                <>
                  <path d="M38 45 Q41 40 44 45" stroke={`hsl(var(${moodColor}))`} strokeWidth="2.5" strokeLinecap="round" fill="none" />
                  <path d="M56 45 Q59 40 62 45" stroke={`hsl(var(${moodColor}))`} strokeWidth="2.5" strokeLinecap="round" fill="none" />
                </>
              ) : (
                <>
                  <circle cx="41" cy="44" r="3" fill={`hsl(var(${moodColor}))`} />
                  <circle cx="59" cy="44" r="3" fill={`hsl(var(${moodColor}))`} />
                </>
              )}
              {mood === "happy" ? (
                <path d="M38 56 Q50 68 62 56" stroke={`hsl(var(${moodColor}))`} strokeWidth="2.5" strokeLinecap="round" fill="none" />
              ) : mood === "neutral" ? (
                <line x1="40" y1="58" x2="60" y2="58" stroke={`hsl(var(${moodColor}))`} strokeWidth="2.5" strokeLinecap="round" />
              ) : (
                <path d="M38 62 Q50 52 62 62" stroke={`hsl(var(${moodColor}))`} strokeWidth="2.5" strokeLinecap="round" fill="none" />
              )}
              {mood === "happy" && (
                <>
                  <circle cx="34" cy="54" r="4" fill={`hsl(var(${moodColor}) / 0.2)`} />
                  <circle cx="66" cy="54" r="4" fill={`hsl(var(${moodColor}) / 0.2)`} />
                </>
              )}
            </svg>
          </div>

          {/* Satisfaction text */}
          <div className="min-w-0 text-right">
            <p className="text-xs font-medium text-muted-foreground mb-0.5">Customer Satisfaction</p>
            <p className="text-lg font-semibold text-foreground">{getMoodLabel(mood)}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{getMoodSublabel(mood, satisfactionPercent)}</p>
            <div className="mt-2 h-1.5 w-full max-w-[180px] rounded-full bg-muted overflow-hidden ml-auto">
              <div
                className={`h-full rounded-full transition-all duration-1000 ease-out ${moodBarClass}`}
                style={{ width: animate ? `${satisfactionPercent}%` : "0%" }}
              />
            </div>
          </div>
        </div>
      </CardContent>

      <style>{`
        @keyframes sunshine-ray-pulse {
          0%, 100% { opacity: 0.4; transform: scaleY(1); }
          50% { opacity: 0.8; transform: scaleY(1.2); }
        }
      `}</style>
    </Card>
  );
}

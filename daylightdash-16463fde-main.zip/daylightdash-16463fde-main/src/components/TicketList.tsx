import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { type Ticket } from "@/data/mockData";
import { ChevronDown, Clock, User, Briefcase, MapPin, Heart } from "lucide-react";

const sentimentColor: Record<string, string> = {
  positive: "bg-success/15 text-success border-success/20",
  neutral: "bg-warning/15 text-warning border-warning/20",
  negative: "bg-urgent/15 text-urgent border-urgent/20",
};

const urgencyLabel: Record<string, string> = {
  urgent: "bg-urgent text-urgent-foreground",
  high: "bg-urgent/80 text-urgent-foreground",
  medium: "bg-warning text-warning-foreground",
  low: "bg-muted text-muted-foreground",
};

const statusStyle: Record<string, string> = {
  open: "bg-urgent/10 text-urgent border-urgent/20",
  pending: "bg-warning/10 text-warning border-warning/20",
  resolved: "bg-success/10 text-success border-success/20",
};

const emotionEmoji: Record<string, string> = {
  angry: "😠",
  frustrated: "😤",
  neutral: "😐",
  happy: "😊",
  delighted: "🤩",
};

const categoryIcon: Record<string, string> = {
  shipping: "📦",
  hardware: "🖥️",
  software: "💻",
  accessories: "🎧",
  general: "💬",
};

interface TicketListProps {
  tickets: Ticket[];
  title?: string;
}

export function TicketList({ tickets, title = "Tickets" }: TicketListProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  return (
    <Card className="animate-fade-in">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg flex items-center gap-2">
          {title}
          <Badge variant="secondary" className="font-sans text-xs">{tickets.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y divide-border">
          {tickets.map((ticket) => {
            const isExpanded = expandedId === ticket.id;
            const created = new Date(ticket.createdAt);

            return (
              <div key={ticket.id}>
                <button
                  onClick={() => setExpandedId(isExpanded ? null : ticket.id)}
                  className="flex items-center gap-3 px-5 py-3.5 w-full text-left hover:bg-muted/50 transition-colors cursor-pointer"
                  aria-expanded={isExpanded}
                >
                  <span className="text-lg shrink-0" aria-hidden="true">{categoryIcon[ticket.category]}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="text-sm font-medium text-foreground truncate">{ticket.subject}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{ticket.customer}</span>
                      <span>·</span>
                      <span>{ticket.id}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <Badge variant="outline" className={`text-xs ${sentimentColor[ticket.sentiment]}`}>
                      {ticket.sentiment}
                    </Badge>
                    {(ticket.urgency === "urgent" || ticket.urgency === "high") && (
                      <Badge className={`text-xs ${urgencyLabel[ticket.urgency]}`}>
                        {ticket.urgency === "urgent" ? "⚠ Urgent" : "High"}
                      </Badge>
                    )}
                    <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform duration-200 ${isExpanded ? "rotate-180" : ""}`} />
                  </div>
                </button>

                <div
                  className={`overflow-hidden transition-all duration-300 ease-in-out ${isExpanded ? "max-h-[500px] opacity-100" : "max-h-0 opacity-0"}`}
                >
                  <div className="px-5 pb-5 pt-1 space-y-4 border-t border-border/50 mx-5">
                    {/* Original message */}
                    <div className="mt-4 rounded-lg bg-muted/40 p-4">
                      <p className="text-xs font-medium text-muted-foreground mb-2">Original Message</p>
                      <p className="text-sm text-foreground leading-relaxed">{ticket.message}</p>
                    </div>

                    {/* Detail grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <DetailItem icon={Clock} label="Created" value={created.toLocaleDateString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })} />
                      <DetailItem icon={User} label="Emotion" value={`${emotionEmoji[ticket.emotion]} ${ticket.emotion}`} />
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Status</p>
                        <Badge variant="outline" className={`text-xs capitalize ${statusStyle[ticket.status]}`}>{ticket.status}</Badge>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Urgency</p>
                        <Badge className={`text-xs capitalize ${urgencyLabel[ticket.urgency]}`}>{ticket.urgency}</Badge>
                      </div>
                    </div>

                    {/* Demographics if available */}
                    {ticket.demographic && (
                      <div className="flex flex-wrap gap-3">
                        {ticket.demographic.occupation && (
                          <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/60 rounded-full px-3 py-1">
                            <Briefcase className="h-3 w-3" /> {ticket.demographic.occupation}
                          </span>
                        )}
                        {ticket.demographic.location && (
                          <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/60 rounded-full px-3 py-1">
                            <MapPin className="h-3 w-3" /> {ticket.demographic.location}
                          </span>
                        )}
                        {ticket.demographic.familyStatus && (
                          <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/60 rounded-full px-3 py-1">
                            <User className="h-3 w-3" /> {ticket.demographic.familyStatus}
                          </span>
                        )}
                        {ticket.demographic.healthCondition && (
                          <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/60 rounded-full px-3 py-1">
                            <Heart className="h-3 w-3" /> {ticket.demographic.healthCondition}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}

function DetailItem({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground mb-1">{label}</p>
      <span className="inline-flex items-center gap-1.5 text-sm text-foreground capitalize">
        <Icon className="h-3.5 w-3.5 text-muted-foreground" />
        {value}
      </span>
    </div>
  );
}

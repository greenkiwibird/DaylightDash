import { useEffect, useState } from "react";

export function ThemeToggle() {
  const [dark, setDark] = useState(() => {
    if (!document.documentElement.classList.contains("light-set")) {
      document.documentElement.classList.add("dark");
      return true;
    }
    return document.documentElement.classList.contains("dark");
  });

  useEffect(() => {
    document.documentElement.classList.add("light-set");
    if (dark) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [dark]);

  return (
    <button
      onClick={() => setDark(!dark)}
      aria-label={dark ? "Switch to light mode" : "Switch to dark mode"}
      className="relative flex items-center h-[30px] w-[84px] rounded-full bg-primary cursor-pointer border-none outline-none transition-colors duration-300"
      style={{ boxShadow: "0 0 14px 4px hsl(var(--primary) / 0.5), 0 0 30px 8px hsl(var(--primary) / 0.2)" }}
    >
      {/* Sliding circle */}
      <span
        className={`absolute top-[3px] h-6 w-6 rounded-full transition-all duration-300 ${
          dark
            ? "left-[calc(100%-1.7rem)] bg-foreground/80"
            : "left-[3px] bg-primary-foreground"
        }`}
      />
      {/* Label */}
      <span
        className={`w-full text-[10px] font-mono font-bold tracking-widest select-none transition-all duration-300 ${
          dark
            ? "pr-8 pl-2 text-primary-foreground"
            : "pl-8 pr-2 text-primary-foreground"
        }`}
      >
        {dark ? "NIGHT" : "DAY"}
      </span>
    </button>
  );
}

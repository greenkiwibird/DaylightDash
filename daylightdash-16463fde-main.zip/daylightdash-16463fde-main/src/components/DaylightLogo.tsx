import daylightLogo from "@/assets/daylight-logo.png";

export function DaylightLogo({ className = "h-6 w-6" }: { className?: string }) {
  return (
    <img
      src={daylightLogo}
      alt="Daylight logo"
      className={`${className} rounded-md object-contain`}
    />
  );
}

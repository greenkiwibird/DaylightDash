import { SidebarProvider } from "@/components/ui/sidebar";
import { DashboardSidebar } from "@/components/DashboardSidebar";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Outlet } from "react-router-dom";

export function DashboardLayout() {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <DashboardSidebar />
        <div className="flex-1 flex flex-col">
          <header className="h-14 border-b flex items-center justify-between px-4 bg-card">
            <h1 className="text-lg font-semibold text-foreground">Customer Insights</h1>
            <ThemeToggle />
          </header>
          <main className="flex-1 p-6 overflow-auto dot-pattern">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

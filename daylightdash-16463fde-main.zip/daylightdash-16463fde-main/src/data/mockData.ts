// Mock data for Daylight Customer Insights Dashboard

export interface Ticket {
  id: string;
  customer: string;
  subject: string;
  message: string;
  category: "shipping" | "hardware" | "software" | "accessories" | "general";
  sentiment: "positive" | "neutral" | "negative";
  sentimentScore: number;
  emotion: "angry" | "frustrated" | "neutral" | "happy" | "delighted";
  urgency: "low" | "medium" | "high" | "urgent";
  status: "open" | "pending" | "resolved";
  createdAt: string;
  demographic?: {
    occupation?: string;
    familyStatus?: string;
    healthCondition?: string;
    location?: string;
  };
}

export const tickets: Ticket[] = [
  { id: "T-1042", customer: "Sarah M.", subject: "Display flickering after update", message: "Hi, ever since the latest software update my display has been flickering constantly. It's giving me terrible migraines and I can't get any writing done. I've tried restarting multiple times but the issue persists. Please help — this is really affecting my work.", category: "software", sentiment: "negative", sentimentScore: 2, emotion: "frustrated", urgency: "high", status: "open", createdAt: "2026-02-13T08:15:00Z", demographic: { occupation: "Writer", healthCondition: "Migraines" } },
  { id: "T-1041", customer: "James K.", subject: "Shipping delay — order #8827", message: "I ordered this laptop over two weeks ago and it still hasn't arrived. Order #8827. The tracking hasn't updated in 5 days. I'm in California and was told delivery would take 3-5 business days. This is completely unacceptable. I need this for my kids' school.", category: "shipping", sentiment: "negative", sentimentScore: 1, emotion: "angry", urgency: "urgent", status: "open", createdAt: "2026-02-13T07:45:00Z", demographic: { location: "California", familyStatus: "Parent of 2" } },
  { id: "T-1040", customer: "Priya N.", subject: "Love the eye-friendly display!", message: "Just wanted to say — I've been coding for 12+ hours a day on this display and my eyes have never felt better. The warm-tone technology is genuinely life-changing. Best purchase I've made all year. Keep up the amazing work!", category: "hardware", sentiment: "positive", sentimentScore: 5, emotion: "delighted", urgency: "low", status: "resolved", createdAt: "2026-02-13T07:30:00Z", demographic: { occupation: "Developer" } },
  { id: "T-1039", customer: "Tom B.", subject: "Keyboard accessory not fitting", message: "The magnetic keyboard accessory I bought doesn't snap into place properly. It keeps sliding off at an angle. Is this a compatibility issue with the latest model? I'd appreciate a replacement or refund.", category: "accessories", sentiment: "negative", sentimentScore: 2, emotion: "frustrated", urgency: "medium", status: "open", createdAt: "2026-02-13T06:50:00Z" },
  { id: "T-1038", customer: "Lena W.", subject: "How to enable night mode?", message: "Hi there, I'm a student and I often work late at night. I heard your laptops have a special night mode that's good for sleep. Could you walk me through how to enable it? I couldn't find it in settings. Thanks!", category: "software", sentiment: "neutral", sentimentScore: 3, emotion: "neutral", urgency: "low", status: "pending", createdAt: "2026-02-12T22:10:00Z", demographic: { occupation: "Student", healthCondition: "Seasonal depression" } },
  { id: "T-1037", customer: "David R.", subject: "VIP — device not powering on", message: "My device completely stopped powering on this morning. No lights, no response to the power button, nothing. I've tried different chargers. This is a critical issue — I have board meetings all week and all my presentations are on this machine.", category: "hardware", sentiment: "negative", sentimentScore: 1, emotion: "angry", urgency: "urgent", status: "open", createdAt: "2026-02-12T21:00:00Z", demographic: { occupation: "Executive" } },
  { id: "T-1036", customer: "Mika S.", subject: "Best laptop I've ever owned!", message: "Honestly, this is hands down the best laptop I've ever used. The display is gorgeous, the battery lasts all day, and it's so lightweight. As a college student carrying it everywhere, it's perfect. Already recommended it to three friends!", category: "general", sentiment: "positive", sentimentScore: 5, emotion: "delighted", urgency: "low", status: "resolved", createdAt: "2026-02-12T19:30:00Z", demographic: { familyStatus: "College student" } },
  { id: "T-1035", customer: "Chen Y.", subject: "Return request — too heavy", message: "I'd like to request a return. The laptop is heavier than I expected and it's causing back pain when I carry it in my bag during my commute. The product page said 'lightweight' but at 2.1kg it's not what I'd consider light.", category: "hardware", sentiment: "negative", sentimentScore: 2, emotion: "frustrated", urgency: "medium", status: "open", createdAt: "2026-02-12T17:15:00Z" },
  { id: "T-1034", customer: "Ana G.", subject: "Stylus pen pairing issue", message: "I'm a designer and I bought the stylus pen to use with the touchscreen. It pairs via Bluetooth but disconnects every few minutes. I've tried re-pairing multiple times. Is there a firmware update I'm missing?", category: "accessories", sentiment: "neutral", sentimentScore: 3, emotion: "neutral", urgency: "medium", status: "pending", createdAt: "2026-02-12T15:45:00Z", demographic: { occupation: "Designer" } },
  { id: "T-1033", customer: "Robert F.", subject: "Shipping confirmation missing", message: "I placed an order three days ago and never received a shipping confirmation email. I checked my spam folder too. Can you confirm whether my order has shipped? Order was placed from Texas.", category: "shipping", sentiment: "negative", sentimentScore: 2, emotion: "frustrated", urgency: "high", status: "open", createdAt: "2026-02-12T14:20:00Z", demographic: { location: "Texas" } },
  { id: "T-1032", customer: "Kim J.", subject: "My kids love the display", message: "Just wanted to share — my three kids all fight over who gets to use the Daylight laptop for homework. They say the screen doesn't hurt their eyes like other screens do. As a teacher and parent, that means the world to me. Thank you!", category: "general", sentiment: "positive", sentimentScore: 5, emotion: "happy", urgency: "low", status: "resolved", createdAt: "2026-02-12T12:00:00Z", demographic: { familyStatus: "Parent of 3", occupation: "Teacher" } },
  { id: "T-1031", customer: "Alex P.", subject: "Software crash on startup", message: "The Daylight OS crashes immediately on startup. I get a brief flash of the desktop and then it reboots into a recovery loop. I'm a developer and I need this machine for work urgently. I've tried safe mode but same issue.", category: "software", sentiment: "negative", sentimentScore: 1, emotion: "angry", urgency: "urgent", status: "open", createdAt: "2026-02-12T10:30:00Z", demographic: { occupation: "Developer" } },
  { id: "T-1030", customer: "Nina H.", subject: "Fast response — thank you!", message: "I had an issue last week with my charger and your support team resolved it within 2 hours. That's the fastest customer service I've ever experienced. Just wanted to say thank you — you've earned a loyal customer.", category: "general", sentiment: "positive", sentimentScore: 5, emotion: "delighted", urgency: "low", status: "resolved", createdAt: "2026-02-11T20:00:00Z" },
  { id: "T-1029", customer: "Oscar M.", subject: "Bezel feels too thick", message: "The bezels on the display feel really thick compared to competitors. For a premium device at this price point, I expected a more modern edge-to-edge design. It's not a dealbreaker but it does feel dated.", category: "hardware", sentiment: "negative", sentimentScore: 2, emotion: "frustrated", urgency: "low", status: "pending", createdAt: "2026-02-11T18:00:00Z" },
  { id: "T-1028", customer: "Eva L.", subject: "Shipping to Alaska?", message: "Hi, do you ship to Alaska? I tried to place an order but Alaska wasn't showing up as a shipping option. I'm in Anchorage and would love to order the Daylight laptop. Thanks in advance!", category: "shipping", sentiment: "neutral", sentimentScore: 3, emotion: "neutral", urgency: "low", status: "resolved", createdAt: "2026-02-11T15:00:00Z", demographic: { location: "Alaska" } },
];

export const sentimentTrend = [
  { month: "Sep", positive: 42, neutral: 30, negative: 28 },
  { month: "Oct", positive: 45, neutral: 28, negative: 27 },
  { month: "Nov", positive: 48, neutral: 25, negative: 27 },
  { month: "Dec", positive: 40, neutral: 22, negative: 38 },
  { month: "Jan", positive: 52, neutral: 26, negative: 22 },
  { month: "Feb", positive: 55, neutral: 24, negative: 21 },
];

export const topLoves = [
  { theme: "Eye-friendly display", mentions: 312, trend: "up" as const },
  { theme: "Fast support response", mentions: 287, trend: "up" as const },
  { theme: "No-friction returns", mentions: 198, trend: "stable" as const },
];

export const topPainPoints = [
  { theme: "Delayed shipping", mentions: 245, trend: "down" as const },
  { theme: "Heavy bezels", mentions: 189, trend: "stable" as const },
  { theme: "Software bugs", mentions: 156, trend: "up" as const },
  { theme: "Accessory compatibility", mentions: 98, trend: "stable" as const },
  { theme: "Battery life concerns", mentions: 76, trend: "up" as const },
];

export const demographicBreakdown = {
  occupations: [
    { name: "Developer", count: 892 },
    { name: "Writer", count: 634 },
    { name: "Designer", count: 521 },
    { name: "Student", count: 487 },
    { name: "Executive", count: 312 },
  ],
  healthConditions: [
    { name: "Migraines", count: 234 },
    { name: "Seasonal depression", count: 156 },
    { name: "TBI", count: 89 },
    { name: "Eye strain", count: 445 },
  ],
  familyStatus: [
    { name: "Parents with young kids", count: 678 },
    { name: "College students", count: 487 },
    { name: "Empty nesters", count: 234 },
  ],
};
